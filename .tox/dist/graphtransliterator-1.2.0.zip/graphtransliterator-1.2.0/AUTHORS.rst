=======
Credits
=======

Development Lead
----------------

* A. Sean Pue `@seanpue <https://github.com/seanpue>`_ <pue@msu.edu>

Contributors
------------

* Valentino Constantinou `@vc1492a <https://github.com/vc1492a>`_
* Rebecca Sutton Koeser `@rlskoeser <https://github.com/rlskoeser>`_
